const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const crypto = require('crypto');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

// Import database and models
const dbConnection = require('./config/database');
const { ApkData, DownloadLink, DeviceRegistration, UpdateAnalytics, RateLimit, AppVersion } = require('./models');
const fileStorage = require('./utils/fileStorage');

const app = express();

// Production Configuration
const IS_PRODUCTION = process.env.NODE_ENV === 'production';
const PORT = process.env.PORT || (IS_PRODUCTION ? 80 : 3000);
const HOST = process.env.HOST || (IS_PRODUCTION ? '0.0.0.0' : 'localhost');

// Database Configuration
const DB_CONFIG = {
  mongoUri: process.env.MONGODB_URI || 'mongodb+srv://brighthex28_db_user:paxb1lgQ9oT4Wrob@cluster0.lzhww6m.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0',
  dbName: process.env.MONGODB_DB_NAME || 'linkserver'
};

// Update API Configuration
const UPDATE_CONFIG = {
  maxFileSize: parseInt(process.env.MAX_FILE_SIZE) || 100 * 1024 * 1024, // 100MB max APK size
  allowedPlatforms: ['ios', 'android'],
  rateLimitWindow: parseInt(process.env.RATE_LIMIT_WINDOW) || 15 * 60 * 1000, // 15 minutes
  rateLimitMax: parseInt(process.env.RATE_LIMIT_MAX) || (IS_PRODUCTION ? 50 : 100), // Stricter in production
  requireDeviceRegistration: process.env.REQUIRE_DEVICE_REGISTRATION === 'true' || IS_PRODUCTION,
  enableAnalytics: process.env.ENABLE_ANALYTICS !== 'false',
  storeUrls: {
    ios: process.env.IOS_APP_STORE_URL || 'https://apps.apple.com/app/id123456789',
    android: process.env.ANDROID_PLAY_STORE_URL || 'https://play.google.com/store/apps/details?id=com.yourapp'
  },
  appStoreId: process.env.IOS_APP_STORE_ID || '123456789',
  corsOrigins: process.env.CORS_ORIGINS ? process.env.CORS_ORIGINS.split(',') : ['*'],
  trustedProxies: process.env.TRUSTED_PROXIES ? process.env.TRUSTED_PROXIES.split(',') : [],
  baseUrl: process.env.BASE_URL || null // Optional: Override base URL for production
};

// Admin Authentication Configuration
const AUTH_CONFIG = {
  jwtSecret: process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-in-production',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '24h',
  adminUsername: process.env.ADMIN_USERNAME || 'admin@brighthex.in',
  adminPassword: process.env.ADMIN_PASSWORD || 'Bright@28', // Change this in production!
  sessionTimeout: parseInt(process.env.SESSION_TIMEOUT) || 24 * 60 * 60 * 1000, // 24 hours
  maxLoginAttempts: parseInt(process.env.MAX_LOGIN_ATTEMPTS) || 5,
  lockoutDuration: parseInt(process.env.LOCKOUT_DURATION) || 15 * 60 * 1000 // 15 minutes
};

// Trust proxy for production (Render, Heroku, etc.)
if (IS_PRODUCTION) {
  app.set('trust proxy', 1);
}

// Security headers middleware
app.use((req, res, next) => {
  // Security headers for production
  if (IS_PRODUCTION) {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  }
  
  // CORS headers
  const origin = req.headers.origin;
  if (UPDATE_CONFIG.corsOrigins.includes('*') || UPDATE_CONFIG.corsOrigins.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin || '*');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
  res.setHeader('Access-Control-Max-Age', '86400'); // 24 hours
  
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  
  next();
});

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(express.static('public'));

// Health check endpoint for deployment platforms
app.get('/health', async (req, res) => {
  try {
    const dbHealth = await dbConnection.healthCheck();
    const storageStats = await fileStorage.getStorageStats();
    
    const health = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV || 'development',
      version: process.env.npm_package_version || '1.0.0',
      database: dbHealth,
      storage: {
        totalFiles: storageStats.totalFiles,
        totalSize: `${(storageStats.totalSize / (1024 * 1024)).toFixed(2)} MB`
      }
    };

    // If database is not healthy, return 503
    if (dbHealth.status !== 'healthy') {
      return res.status(503).json(health);
    }

    res.status(200).json(health);
  } catch (error) {
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: error.message
    });
  }
});

// Initialize database connection and file storage
async function initializeDatabase() {
  try {
    await dbConnection.connect();
    fileStorage.initialize();
    console.log('✅ Database and file storage initialized');
  } catch (error) {
    console.error('❌ Failed to initialize database:', error);
    process.exit(1);
  }
}

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadsDir = './uploads';
    try {
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }
      cb(null, uploadsDir);
    } catch (error) {
      console.error('❌ Failed to create uploads directory:', error);
      cb(error, null);
    }
  },
  filename: (req, file, cb) => {
    const timestamp = Date.now();
    const filename = `${timestamp}-${file.originalname}`;
    cb(null, filename);
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 104857600, // 100MB default
    files: 1
  },
  fileFilter: (req, file, cb) => {
    // Accept APK files and other common mobile app formats
    const allowedMimes = [
      'application/vnd.android.package-archive', // APK
      'application/octet-stream', // Generic binary
      'application/zip' // Sometimes APKs are detected as zip
    ];
    
    const allowedExtensions = ['.apk', '.ipa'];
    const fileExtension = path.extname(file.originalname).toLowerCase();
    
    if (allowedMimes.includes(file.mimetype) || allowedExtensions.includes(fileExtension)) {
      cb(null, true);
    } else {
      cb(new Error(`Invalid file type. Only APK and IPA files are allowed. Received: ${file.mimetype}`), false);
    }
  }
});

// Helper functions
function generateUniqueToken() {
  return crypto.randomBytes(16).toString('hex');
}

// Authentication helper functions
function generateJWT(payload) {
  return jwt.sign(payload, AUTH_CONFIG.jwtSecret, {
    expiresIn: AUTH_CONFIG.jwtExpiresIn
  });
}

function verifyJWT(token) {
  try {
    return jwt.verify(token, AUTH_CONFIG.jwtSecret);
  } catch (error) {
    return null;
  }
}

async function hashPassword(password) {
  const saltRounds = 12;
  return await bcrypt.hash(password, saltRounds);
}

async function comparePassword(password, hashedPassword) {
  return await bcrypt.compare(password, hashedPassword);
}

// In-memory store for login attempts (in production, use Redis or database)
const loginAttempts = new Map();

function trackLoginAttempt(ip, success = false) {
  const key = `login_attempts_${ip}`;
  const now = Date.now();
  
  if (!loginAttempts.has(key)) {
    loginAttempts.set(key, { attempts: 0, lastAttempt: now, lockedUntil: null });
  }
  
  const record = loginAttempts.get(key);
  
  if (success) {
    // Reset on successful login
    loginAttempts.delete(key);
    return { allowed: true, attemptsLeft: AUTH_CONFIG.maxLoginAttempts };
  }
  
  // Check if currently locked
  if (record.lockedUntil && now < record.lockedUntil) {
    return { 
      allowed: false, 
      lockedUntil: record.lockedUntil,
      message: 'Account temporarily locked due to too many failed attempts'
    };
  }
  
  // Reset lock if expired
  if (record.lockedUntil && now >= record.lockedUntil) {
    record.attempts = 0;
    record.lockedUntil = null;
  }
  
  // Increment attempts
  record.attempts++;
  record.lastAttempt = now;
  
  // Check if should be locked
  if (record.attempts >= AUTH_CONFIG.maxLoginAttempts) {
    record.lockedUntil = now + AUTH_CONFIG.lockoutDuration;
    return {
      allowed: false,
      lockedUntil: record.lockedUntil,
      message: `Too many failed attempts. Account locked for ${AUTH_CONFIG.lockoutDuration / 60000} minutes.`
    };
  }
  
  return {
    allowed: true,
    attemptsLeft: AUTH_CONFIG.maxLoginAttempts - record.attempts,
    message: `Invalid credentials. ${AUTH_CONFIG.maxLoginAttempts - record.attempts} attempts remaining.`
  };
}

async function createDownloadLink(channelData) {
  const token = channelData.channelId; // Use channel ID as token instead of generating random token
  
  try {
    const downloadLink = new DownloadLink({
      token: token,
      channelId: channelData.channelId,
      channelName: channelData.channelName,
      channelUsername: channelData.channelUsername,
      downloadCount: 0,
      isActive: true
    });
    
    await downloadLink.save();
    console.log(`📎 Download link created: ${token} for channel ${channelData.channelName}`);
    return token;
  } catch (error) {
    console.error('❌ Error creating download link:', error);
    throw error;
  }
}

// Helper functions for update management
function validateVersionFormat(version) {
  const versionRegex = /^\d+\.\d+\.\d+$/;
  return versionRegex.test(version);
}

function compareVersions(version1, version2) {
  const v1Parts = version1.split('.').map(Number);
  const v2Parts = version2.split('.').map(Number);
  
  for (let i = 0; i < Math.max(v1Parts.length, v2Parts.length); i++) {
    const v1Part = v1Parts[i] || 0;
    const v2Part = v2Parts[i] || 0;
    
    if (v1Part > v2Part) return 1;
    if (v1Part < v2Part) return -1;
  }
  return 0;
}

function generateUpdateId() {
  return `update_${Date.now()}_${crypto.randomBytes(8).toString('hex')}`;
}

async function trackUpdateEvent(eventType, deviceId, version, platform, userAgent = null) {
  try {
    // Skip analytics if deviceId is null/undefined for non-device events
    if (!deviceId) {
      console.log(`📊 Skipping analytics for ${eventType} - no device ID`);
      return null;
    }
    
    const eventId = generateUniqueToken();
    
    const analyticsEvent = new UpdateAnalytics({
      eventId: eventId,
      eventType: eventType,
      deviceId: deviceId,
      version: version,
      platform: platform,
      userAgent: userAgent
    });
    
    await analyticsEvent.save();
    console.log(`📊 Analytics event tracked: ${eventType} for device ${deviceId}`);
    return eventId;
  } catch (error) {
    console.error('❌ Error tracking update event:', error);
    // Don't throw error for analytics failures
    return null;
  }
}

// Helper function to get the base URL for the application
function getBaseUrl(req) {
  // Use environment variable if set (for production deployments)
  if (UPDATE_CONFIG.baseUrl) {
    return UPDATE_CONFIG.baseUrl;
  }
  
  // Otherwise construct from request
  return req.protocol + '://' + req.get('host');
}

// Rate limiting middleware
async function rateLimitMiddleware(req, res, next) {
  try {
    const clientIP = req.ip || req.connection.remoteAddress;
    const now = new Date();
    const windowStart = new Date(now.getTime() - UPDATE_CONFIG.rateLimitWindow);
    
    // Find or create rate limit record
    let rateLimitRecord = await RateLimit.findOne({ ipAddress: clientIP });
    
    if (!rateLimitRecord) {
      rateLimitRecord = new RateLimit({
        ipAddress: clientIP,
        requests: [now]
      });
    } else {
      // Clean old requests
      rateLimitRecord.requests = rateLimitRecord.requests.filter(
        timestamp => timestamp > windowStart
      );
      
      // Check if limit exceeded
      if (rateLimitRecord.requests.length >= UPDATE_CONFIG.rateLimitMax) {
        return res.status(429).json({
          success: false,
          message: 'Too many requests. Please try again later.',
          retryAfter: Math.ceil(UPDATE_CONFIG.rateLimitWindow / 1000)
        });
      }
      
      // Add current request
      rateLimitRecord.requests.push(now);
    }
    
    await rateLimitRecord.save();
    next();
  } catch (error) {
    console.error('❌ Rate limiting error:', error);
    next(); // Continue on error to avoid blocking requests
  }
}

// Input sanitization middleware
function sanitizeInput(req, res, next) {
  if (req.body) {
    for (const key in req.body) {
      if (typeof req.body[key] === 'string') {
        // Basic XSS prevention
        req.body[key] = req.body[key]
          .replace(/[<>]/g, '')
          .trim()
          .substring(0, 1000); // Limit length
      }
    }
  }
  next();
}

// Device validation middleware
async function validateDevice(req, res, next) {
  try {
    const { deviceId, platform } = req.body;
    
    if (UPDATE_CONFIG.requireDeviceRegistration && deviceId) {
      const device = await DeviceRegistration.findOne({ deviceId: deviceId });
      if (!device) {
        return res.status(401).json({
          success: false,
          message: 'Device not registered. Please register first.',
          requiresRegistration: true
        });
      }
    }
    
    if (platform && !UPDATE_CONFIG.allowedPlatforms.includes(platform)) {
      return res.status(400).json({
        success: false,
        message: `Invalid platform. Allowed: ${UPDATE_CONFIG.allowedPlatforms.join(', ')}`
      });
    }
    
    next();
  } catch (error) {
    console.error('❌ Device validation error:', error);
    res.status(500).json({
      success: false,
      message: 'Device validation failed'
    });
  }
}

// Authentication middleware
function authenticateAdmin(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN
    
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Access token required',
        requiresAuth: true
      });
    }
    
    const decoded = verifyJWT(token);
    if (!decoded || decoded.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Invalid or expired token',
        requiresAuth: true
      });
    }
    
    // Check token expiration
    if (decoded.exp * 1000 < Date.now()) {
      return res.status(401).json({
        success: false,
        message: 'Token expired',
        requiresAuth: true
      });
    }
    
    req.admin = decoded;
    next();
  } catch (error) {
    console.error('❌ Authentication error:', error);
    res.status(500).json({
      success: false,
      message: 'Authentication failed'
    });
  }
}

// Optional authentication middleware (for routes that can work with or without auth)
function optionalAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    
    if (token) {
      const decoded = verifyJWT(token);
      if (decoded && decoded.role === 'admin') {
        req.admin = decoded;
      }
    }
    
    next();
  } catch (error) {
    // Continue without authentication on error
    next();
  }
}

// Routes

// Redirect main page to login for admin access
app.get('/', (req, res) => {
  // For admin access, redirect to login page
  res.redirect('/login');
});

// Serve the public index page for app users
app.get('/public', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Serve the login page
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'login.html'));
});

// Serve the dashboard (client-side authentication check)
app.get('/dashboard', (req, res) => {
  // Always serve the dashboard HTML - authentication will be handled client-side
  // This prevents redirect loops and allows proper token-based authentication
  res.sendFile(path.join(__dirname, 'dashboard.html'));
});

// Serve the upload page (protected)
app.get('/upload', (req, res) => {
  res.sendFile(path.join(__dirname, 'upload.html'));
});

// Serve the channels page (protected)
app.get('/channels', (req, res) => {
  res.sendFile(path.join(__dirname, 'channels.html'));
});

// Serve the upload test page
app.get('/test-upload', (req, res) => {
  res.sendFile(path.join(__dirname, 'test-upload.html'));
});

// Authentication API Routes

// POST - Admin login
app.post('/api/auth/login', rateLimitMiddleware, sanitizeInput, async (req, res) => {
  try {
    const { username, password } = req.body;
    const clientIP = req.ip || req.connection.remoteAddress;
    
    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: 'Username and password are required'
      });
    }
    
    // Check login attempts
    const attemptCheck = trackLoginAttempt(clientIP, false);
    if (!attemptCheck.allowed) {
      return res.status(429).json({
        success: false,
        message: attemptCheck.message,
        lockedUntil: attemptCheck.lockedUntil
      });
    }
    
    // Validate credentials
    if (username !== AUTH_CONFIG.adminUsername) {
      trackLoginAttempt(clientIP, false);
      return res.status(401).json({
        success: false,
        message: attemptCheck.message || 'Invalid credentials'
      });
    }
    
    // For production, you should hash the admin password and store it securely
    // For now, we'll do a simple comparison but log a warning
    let isValidPassword = false;
    
    if (IS_PRODUCTION && AUTH_CONFIG.adminPassword.startsWith('$2b$')) {
      // Password is hashed
      isValidPassword = await comparePassword(password, AUTH_CONFIG.adminPassword);
    } else {
      // Plain text password (development only)
      isValidPassword = password === AUTH_CONFIG.adminPassword;
      if (!IS_PRODUCTION) {
        console.log('⚠️  WARNING: Using plain text password in development mode');
      } else {
        console.log('⚠️  WARNING: Plain text password detected in production! Please hash your admin password.');
      }
    }
    
    if (!isValidPassword) {
      trackLoginAttempt(clientIP, false);
      return res.status(401).json({
        success: false,
        message: attemptCheck.message || 'Invalid credentials'
      });
    }
    
    // Successful login
    trackLoginAttempt(clientIP, true);
    
    // Generate JWT token
    const tokenPayload = {
      username: username,
      role: 'admin',
      loginTime: new Date().toISOString(),
      ip: clientIP
    };
    
    const token = generateJWT(tokenPayload);
    
    console.log(`🔐 Admin login successful: ${username} from ${clientIP}`);
    
    res.json({
      success: true,
      message: 'Login successful',
      token: token,
      expiresIn: AUTH_CONFIG.jwtExpiresIn,
      user: {
        username: username,
        role: 'admin',
        loginTime: tokenPayload.loginTime
      }
    });
  } catch (error) {
    console.error('❌ Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Login failed: ' + error.message
    });
  }
});

// POST - Admin logout
app.post('/api/auth/logout', authenticateAdmin, (req, res) => {
  try {
    console.log(`🔐 Admin logout: ${req.admin.username}`);
    
    // In a real implementation, you might want to blacklist the token
    // For now, we'll just return success (client should delete the token)
    
    res.json({
      success: true,
      message: 'Logout successful'
    });
  } catch (error) {
    console.error('❌ Logout error:', error);
    res.status(500).json({
      success: false,
      message: 'Logout failed: ' + error.message
    });
  }
});

// GET - Verify token and get admin info
app.get('/api/auth/me', authenticateAdmin, (req, res) => {
  try {
    res.json({
      success: true,
      user: {
        username: req.admin.username,
        role: req.admin.role,
        loginTime: req.admin.loginTime,
        tokenExp: new Date(req.admin.exp * 1000).toISOString()
      }
    });
  } catch (error) {
    console.error('❌ Auth verification error:', error);
    res.status(500).json({
      success: false,
      message: 'Authentication verification failed'
    });
  }
});

// POST - Change admin password
app.post('/api/auth/change-password', authenticateAdmin, sanitizeInput, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    
    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Current password and new password are required'
      });
    }
    
    if (newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'New password must be at least 6 characters long'
      });
    }
    
    // Verify current password
    let isValidCurrentPassword = false;
    
    if (AUTH_CONFIG.adminPassword.startsWith('$2b$')) {
      isValidCurrentPassword = await comparePassword(currentPassword, AUTH_CONFIG.adminPassword);
    } else {
      isValidCurrentPassword = currentPassword === AUTH_CONFIG.adminPassword;
    }
    
    if (!isValidCurrentPassword) {
      return res.status(401).json({
        success: false,
        message: 'Current password is incorrect'
      });
    }
    
    // Hash new password
    const hashedNewPassword = await hashPassword(newPassword);
    
    console.log(`🔐 Password change request for admin: ${req.admin.username}`);
    console.log(`🔑 New hashed password: ${hashedNewPassword}`);
    console.log('⚠️  Please update your environment variable ADMIN_PASSWORD with the hashed password above');
    
    res.json({
      success: true,
      message: 'Password hashed successfully. Please update your environment variable ADMIN_PASSWORD with the provided hash.',
      hashedPassword: hashedNewPassword,
      note: 'The password change will take effect after updating the environment variable and restarting the server.'
    });
  } catch (error) {
    console.error('❌ Password change error:', error);
    res.status(500).json({
      success: false,
      message: 'Password change failed: ' + error.message
    });
  }
});

// Update Management API Routes

// POST - Check for version updates (used by UpdateService.checkStoreUpdate)
app.post('/api/check-version', rateLimitMiddleware, sanitizeInput, validateDevice, async (req, res) => {
  try {
    const { platform, currentVersion, bundleId, deviceId } = req.body;
    
    if (!platform || !currentVersion || !bundleId) {
      return res.status(400).json({
        success: false,
        message: 'Platform, currentVersion, and bundleId are required'
      });
    }
    
    // Validate version format
    if (!validateVersionFormat(currentVersion)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid version format. Use semantic versioning (e.g., 1.0.0)'
      });
    }
    
    // Get latest version for platform
    const latestApk = await ApkData.findOne({ 
      platform: { $in: [platform, 'both'] },
      isActive: true 
    }).sort({ uploadDate: -1 });
    
    const latestVersion = latestApk ? latestApk.version : '1.0.0';
    const updateAvailable = compareVersions(latestVersion, currentVersion) > 0;
    
    // Track version check event
    if (deviceId) {
      await trackUpdateEvent('version_check', deviceId, currentVersion, platform, req.get('User-Agent'));
    }
    
    // Generate store URLs
    const storeUrls = {
      ios: UPDATE_CONFIG.storeUrls.ios,
      android: UPDATE_CONFIG.storeUrls.android
    };
    
    const response = {
      success: true,
      updateAvailable,
      currentVersion,
      latestVersion,
      platform,
      bundleId,
      storeUrl: storeUrls[platform] || storeUrls.android,
      updateType: 'store',
      releaseNotes: 'Bug fixes and performance improvements',
      isForced: false, // Set to true for mandatory updates
      timestamp: new Date().toISOString()
    };
    
    // Add app store specific data
    if (platform === 'ios') {
      response.appStoreId = UPDATE_CONFIG.appStoreId;
    }
    
    console.log(`📱 Version check: ${platform} v${currentVersion} -> v${latestVersion} (Update: ${updateAvailable})`);
    
    res.json(response);
  } catch (error) {
    console.error('Version check error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to check version: ' + error.message
    });
  }
});

// GET - Get update metadata for platform
app.get('/api/updates/:platform', rateLimitMiddleware, async (req, res) => {
  try {
    const { platform } = req.params;
    const { version, deviceId } = req.query;
    
    if (!['ios', 'android'].includes(platform)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid platform. Use "ios" or "android"'
      });
    }
    
    // Track metadata request
    if (deviceId) {
      await trackUpdateEvent('metadata_request', deviceId, version || 'unknown', platform);
    }
    
    // Get latest APK for platform
    const latestApk = await ApkData.findOne({ 
      platform: { $in: [platform, 'both'] },
      isActive: true 
    }).sort({ uploadDate: -1 });
    
    const updateInfo = {
      success: true,
      platform,
      currentVersion: latestApk ? latestApk.version : '1.0.0',
      downloadUrl: latestApk ? getBaseUrl(req) + '/api/updates/download/' + platform : null,
      fileSize: latestApk ? latestApk.fileSize || 0 : 0,
      releaseDate: latestApk ? latestApk.uploadDate : new Date().toISOString(),
      releaseNotes: 'Latest version with improvements and bug fixes',
      isAvailable: !!latestApk,
      checksum: latestApk ? latestApk.checksum : null,
      minimumOsVersion: platform === 'ios' ? '12.0' : '21',
      supportedArchitectures: platform === 'ios' ? ['arm64'] : ['arm64-v8a', 'armeabi-v7a']
    };
    
    res.json(updateInfo);
  } catch (error) {
    console.error('Update metadata error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get update metadata: ' + error.message
    });
  }
});

// GET - Download APK for platform (direct download)
app.get('/api/updates/download/:platform', rateLimitMiddleware, async (req, res) => {
  try {
    const { platform } = req.params;
    const { deviceId, version } = req.query;
    
    if (!['ios', 'android'].includes(platform)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid platform'
      });
    }
    
    // Get latest APK for platform
    const latestApk = await ApkData.findOne({ 
      platform: { $in: [platform, 'both'] },
      isActive: true 
    }).sort({ uploadDate: -1 });

    if (!latestApk || !latestApk.fileId) {
      return res.status(404).json({
        success: false,
        message: 'No update file available for download'
      });
    }
    
    // Track download start
    if (deviceId) {
      await trackUpdateEvent('download_start', deviceId, version || latestApk.version, platform);
    }
    
    // Increment download count
    await ApkData.findByIdAndUpdate(latestApk._id, { 
      $inc: { totalDownloads: 1 } 
    });
    
    // Set headers for APK download
    const fileName = `${latestApk.name}_v${latestApk.version}.apk`;
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Length', latestApk.fileSize || 0);
    res.setHeader('Cache-Control', 'no-cache');
    
    try {
      // Stream the file from GridFS
      const fileStream = fileStorage.getApkFileStream(latestApk.fileId);
      
      fileStream.on('end', async () => {
        // Track successful download
        if (deviceId) {
          await trackUpdateEvent('download_complete', deviceId, version || latestApk.version, platform);
        }
        console.log(`📱 Update downloaded: ${platform} v${latestApk.version} by device ${deviceId || 'unknown'}`);
      });
      
      fileStream.on('error', async (error) => {
        console.error('Download stream error:', error);
        if (deviceId) {
          await trackUpdateEvent('download_error', deviceId, version || latestApk.version, platform);
        }
        if (!res.headersSent) {
          res.status(500).json({
            success: false,
            message: 'Download failed'
          });
        }
      });
      
      fileStream.pipe(res);
    } catch (error) {
      console.error('GridFS stream error:', error);
      if (deviceId) {
        await trackUpdateEvent('download_error', deviceId, version || latestApk.version, platform);
      }
      res.status(500).json({
        success: false,
        message: 'File stream failed'
      });
    }
    
  } catch (error) {
    console.error('Download error:', error);
    res.status(500).json({
      success: false,
      message: 'Download failed: ' + error.message
    });
  }
});

// POST - Register device for updates
app.post('/api/updates/register', rateLimitMiddleware, sanitizeInput, async (req, res) => {
  try {
    const { deviceId, platform, appVersion, osVersion, deviceModel } = req.body;
    
    if (!deviceId || !platform) {
      return res.status(400).json({
        success: false,
        message: 'Device ID and platform are required'
      });
    }
    
    // Check if device already exists
    let device = await DeviceRegistration.findOne({ deviceId: deviceId });
    
    if (device) {
      // Update existing device
      device.appVersion = appVersion || device.appVersion;
      device.osVersion = osVersion || device.osVersion;
      device.deviceModel = deviceModel || device.deviceModel;
      device.lastCheckAt = new Date();
      await device.save();
    } else {
      // Create new device registration
      device = new DeviceRegistration({
        deviceId,
        platform,
        appVersion: appVersion || 'unknown',
        osVersion: osVersion || 'unknown',
        deviceModel: deviceModel || 'unknown',
        lastCheckAt: new Date(),
        updateCount: 0
      });
      await device.save();
    }
    
    // Track registration
    await trackUpdateEvent('device_register', deviceId, appVersion || 'unknown', platform);
    
    console.log(`📱 Device registered: ${deviceId} (${platform})`);
    
    res.json({
      success: true,
      message: device.isNew ? 'Device registered successfully' : 'Device updated successfully',
      deviceId,
      registrationToken: generateUniqueToken()
    });
  } catch (error) {
    console.error('Device registration error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to register device: ' + error.message
    });
  }
});

// POST - Track update analytics
app.post('/api/analytics/update', rateLimitMiddleware, sanitizeInput, validateDevice, async (req, res) => {
  try {
    const { eventType, deviceId, version, platform, metadata } = req.body;
    
    if (!eventType || !deviceId) {
      return res.status(400).json({
        success: false,
        message: 'Event type and device ID are required'
      });
    }
    
    const eventId = await trackUpdateEvent(eventType, deviceId, version, platform);
    
    // Add additional metadata if provided
    if (metadata) {
      await UpdateAnalytics.findOneAndUpdate(
        { eventId: eventId },
        { $set: { metadata: metadata } }
      );
    }
    
    // Update device last check time
    const device = await DeviceRegistration.findOne({ deviceId: deviceId });
    if (device) {
      device.lastCheckAt = new Date();
      if (eventType === 'update_complete') {
        device.updateCount++;
      }
      await device.save();
    }
    
    res.json({
      success: true,
      eventId,
      message: 'Analytics event tracked successfully'
    });
  } catch (error) {
    console.error('Analytics tracking error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to track analytics: ' + error.message
    });
  }
});

// GET - Get update analytics
app.get('/api/analytics/updates', async (req, res) => {
  try {
    const { platform, eventType, limit = 100 } = req.query;
    
    // Build query filters
    const query = {};
    if (platform) query.platform = platform;
    if (eventType) query.eventType = eventType;
    
    // Get filtered events
    const events = await UpdateAnalytics.find(query)
      .sort({ timestamp: -1 })
      .limit(parseInt(limit))
      .lean();
    
    // Get total counts for summary
    const totalEvents = await UpdateAnalytics.countDocuments();
    const registeredDevicesCount = await DeviceRegistration.countDocuments();
    
    // Generate event type statistics
    const eventTypeStats = await UpdateAnalytics.aggregate([
      { $group: { _id: '$eventType', count: { $sum: 1 } } }
    ]);
    
    // Generate platform statistics
    const platformStats = await UpdateAnalytics.aggregate([
      { $group: { _id: '$platform', count: { $sum: 1 } } }
    ]);
    
    // Convert aggregation results to objects
    const eventTypes = {};
    eventTypeStats.forEach(stat => {
      eventTypes[stat._id] = stat.count;
    });
    
    const platforms = {};
    platformStats.forEach(stat => {
      platforms[stat._id] = stat.count;
    });
    
    const summary = {
      totalEvents,
      filteredEvents: events.length,
      eventTypes,
      platforms,
      recentActivity: events.slice(0, 10)
    };
    
    res.json({
      success: true,
      summary,
      events,
      registeredDevices: registeredDevicesCount
    });
  } catch (error) {
    console.error('Analytics retrieval error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get analytics: ' + error.message
    });
  }
});

// POST - Send update notification (webhook for push notifications)
app.post('/api/notifications/update', async (req, res) => {
  try {
    const { deviceIds, title, body, updateInfo, platform } = req.body;
    
    if (!deviceIds || !Array.isArray(deviceIds) || deviceIds.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Device IDs array is required'
      });
    }
    
    // In a real implementation, this would integrate with FCM, APNs, or OneSignal
    // For now, we'll simulate the notification sending
    
    const notificationData = {
      title: title || 'App Update Available',
      body: body || 'A new version of the app is ready to install',
      updateInfo: updateInfo || {},
      platform: platform || 'android',
      sentAt: new Date().toISOString(),
      deviceCount: deviceIds.length
    };
    
    // Track notification events
    for (const deviceId of deviceIds) {
      await trackUpdateEvent('notification_sent', deviceId, updateInfo?.version || 'unknown', platform || 'unknown');
    }
    
    console.log(`📱 Update notifications sent to ${deviceIds.length} devices`);
    
    // Simulate notification delivery (replace with actual push notification service)
    const deliveryResults = deviceIds.map(deviceId => ({
      deviceId,
      status: 'sent',
      messageId: generateUniqueToken()
    }));
    
    res.json({
      success: true,
      message: `Notifications sent to ${deviceIds.length} devices`,
      notificationData,
      deliveryResults
    });
  } catch (error) {
    console.error('Notification sending error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to send notifications: ' + error.message
    });
  }
});

// GET - Get registered devices
app.get('/api/devices', async (req, res) => {
  try {
    const { platform, limit = 50 } = req.query;
    
    // Build query filters
    const query = {};
    if (platform) query.platform = platform;
    
    // Get devices with filtering and sorting
    const devices = await DeviceRegistration.find(query)
      .sort({ lastCheckAt: -1 })
      .limit(parseInt(limit))
      .lean();
    
    // Get total device count
    const totalDevices = await DeviceRegistration.countDocuments();
    
    // Get platform statistics
    const platformStats = await DeviceRegistration.aggregate([
      { $group: { _id: '$platform', count: { $sum: 1 } } }
    ]);
    
    // Convert platform stats to object
    const platforms = {};
    platformStats.forEach(stat => {
      platforms[stat._id] = stat.count;
    });
    
    // Count recently active devices (last 24 hours)
    const dayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const recentlyActive = await DeviceRegistration.countDocuments({
      lastCheckAt: { $gt: dayAgo }
    });
    
    const summary = {
      totalDevices,
      platforms,
      recentlyActive
    };
    
    res.json({
      success: true,
      summary,
      devices
    });
  } catch (error) {
    console.error('Device listing error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get devices: ' + error.message
    });
  }
});

// API Routes

// GET - Get statistics
app.get('/api/stats', async (req, res) => {
  try {
    // Get active channels count
    const activeChannels = await DownloadLink.countDocuments({ isActive: true });
    
    // Get total downloads from all APKs
    const totalDownloadsResult = await ApkData.aggregate([
      { $group: { _id: null, total: { $sum: '$totalDownloads' } } }
    ]);
    const totalDownloads = totalDownloadsResult.length > 0 ? totalDownloadsResult[0].total : 0;
    
    // Get latest app version
    const latestApk = await ApkData.findOne({ isActive: true }).sort({ uploadDate: -1 });
    const appVersion = latestApk ? latestApk.version : '1.0.0';
    
    res.json({
      success: true,
      totalDownloads,
      activeChannels,
      appVersion
    });
  } catch (error) {
    console.error('Stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get statistics: ' + error.message
    });
  }
});

// GET - Get all versions of an app
app.get('/api/versions/:appName', async (req, res) => {
  try {
    const { appName } = req.params;
    const { platform } = req.query;
    
    const query = { name: appName };
    if (platform) {
      query.platform = platform;
    }
    
    const versions = await ApkData.find(query)
      .sort({ uploadDate: -1 })
      .select('name version platform fileSize checksum totalDownloads isActive uploadDate createdAt')
      .lean();
    
    // Add download URLs to each version
    const baseUrl = process.env.BASE_URL || `http://${req.get('host')}`;
    const versionsWithUrls = versions.map(version => ({
      ...version,
      downloadUrl: `${baseUrl}/download/${version._id}`,
      isLatest: versions[0]._id.toString() === version._id.toString()
    }));
    
    res.json({
      success: true,
      appName: appName,
      totalVersions: versions.length,
      versions: versionsWithUrls
    });
  } catch (error) {
    console.error('Versions retrieval error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get versions: ' + error.message
    });
  }
});

// GET - Get all apps
app.get('/api/apps', async (req, res) => {
  try {
    const apps = await ApkData.aggregate([
      {
        $group: {
          _id: { name: '$name', platform: '$platform' },
          latestVersion: { $max: '$version' },
          totalVersions: { $sum: 1 },
          totalDownloads: { $sum: '$totalDownloads' },
          latestUpload: { $max: '$uploadDate' },
          fileSize: { $last: '$fileSize' }
        }
      },
      {
        $project: {
          _id: 0,
          name: '$_id.name',
          platform: '$_id.platform',
          latestVersion: 1,
          totalVersions: 1,
          totalDownloads: 1,
          latestUpload: 1,
          fileSize: 1
        }
      },
      { $sort: { latestUpload: -1 } }
    ]);
    
    // Add download URLs
    const baseUrl = process.env.BASE_URL || `http://${req.get('host')}`;
    const appsWithUrls = apps.map(app => ({
      ...app,
      downloadUrl: `${baseUrl}/download/latest/${app.platform}`,
      versionsUrl: `${baseUrl}/api/versions/${app.name}?platform=${app.platform}`
    }));
    
    res.json({
      success: true,
      totalApps: apps.length,
      apps: appsWithUrls
    });
  } catch (error) {
    console.error('Apps retrieval error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get apps: ' + error.message
    });
  }
});

// GET - Get all channels (Admin only)
app.get('/api/channels', authenticateAdmin, async (req, res) => {
  try {
    const channels = await DownloadLink.find({})
      .sort({ createdAt: -1 })
      .lean();
    
    // Format channels for response
    const formattedChannels = channels.map(channel => ({
      downloadToken: channel.token,
      channelId: channel.channelId,
      channelName: channel.channelName,
      channelUsername: channel.channelUsername,
      downloadCount: channel.downloadCount,
      isActive: channel.isActive,
      createdAt: channel.createdAt
    }));
    
    res.json({
      success: true,
      channels: formattedChannels
    });
  } catch (error) {
    console.error('Channels retrieval error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get channels: ' + error.message
    });
  }
});

// POST - Add new telegram channel (Admin only)
app.post('/api/channels', authenticateAdmin, async (req, res) => {
  try {
    const { channelId, channelName, channelUsername } = req.body;
    
    if (!channelId || !channelName) {
      return res.status(400).json({
        success: false,
        message: 'Channel ID and name are required'
      });
    }
    
    // Check if channel already exists
    const existingChannel = await DownloadLink.findOne({ channelId: channelId });
    
    if (existingChannel) {
      return res.status(400).json({
        success: false,
        message: 'Channel already exists'
      });
    }
    
    const channelData = {
      channelId,
      channelName,
      channelUsername: channelUsername || null
    };
    
    const token = await createDownloadLink(channelData);
    
    res.json({
      success: true,
      message: 'Channel added successfully',
      downloadToken: token,
      downloadUrl: getBaseUrl(req) + '/d/' + token
    });
  } catch (error) {
    console.error('Add channel error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add channel: ' + error.message
    });
  }
});

// PUT - Toggle channel status (Admin only)
app.put('/api/channels/:token/toggle', authenticateAdmin, async (req, res) => {
  try {
    const { token } = req.params;
    const channel = await DownloadLink.findOne({ token: token });
    
    if (!channel) {
      return res.status(404).json({
        success: false,
        message: 'Channel not found'
      });
    }
    
    channel.isActive = !channel.isActive;
    await channel.save();
    
    res.json({
      success: true,
      message: `Channel ${channel.isActive ? 'activated' : 'deactivated'} successfully`
    });
  } catch (error) {
    console.error('Toggle channel error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to toggle channel status: ' + error.message
    });
  }
});

// DELETE - Delete channel (Admin only)
app.delete('/api/channels/:token', authenticateAdmin, async (req, res) => {
  try {
    const { token } = req.params;
    
    const channel = await DownloadLink.findOneAndDelete({ token: token });
    
    if (!channel) {
      return res.status(404).json({
        success: false,
        message: 'Channel not found'
      });
    }
    
    res.json({
      success: true,
      message: 'Channel deleted successfully'
    });
  } catch (error) {
    console.error('Delete channel error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete channel: ' + error.message
    });
  }
});

// POST - Upload new APK (Admin only)
app.post('/upload', authenticateAdmin, (req, res, next) => {
  upload.single('apkFile')(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      console.error('❌ Multer error:', err);
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({
          success: false,
          message: 'File too large. Maximum size is 100MB.'
        });
      }
      return res.status(400).json({
        success: false,
        message: 'Upload error: ' + err.message
      });
    } else if (err) {
      console.error('❌ Upload error:', err);
      return res.status(400).json({
        success: false,
        message: err.message
      });
    }
    next();
  });
}, async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No APK file uploaded'
      });
    }

    console.log('📁 File upload received:', {
      originalname: req.file.originalname,
      filename: req.file.filename,
      path: req.file.path,
      size: req.file.size
    });

    // Check if file exists at the path
    if (!fs.existsSync(req.file.path)) {
      console.error('❌ Uploaded file not found at path:', req.file.path);
      return res.status(500).json({
        success: false,
        message: 'Upload failed: File not found at expected path'
      });
    }

    const appName = req.body.appName || req.file.originalname;
    const version = req.body.version || '1.0.0';
    const platform = req.body.platform || 'android';

    // Validate version format
    if (!validateVersionFormat(version)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid version format. Use semantic versioning (e.g., 1.0.0)'
      });
    }

    // Calculate file checksum first to check for duplicates
    console.log('🔍 Calculating file checksum...');
    const fileBuffer = fs.readFileSync(req.file.path);
    const fileChecksum = crypto.createHash('md5').update(fileBuffer).digest('hex');
    
    // Check if this exact file already exists (same checksum)
    const existingFile = await ApkData.findOne({ 
      checksum: fileChecksum,
      name: appName,
      platform: platform 
    });
    
    if (existingFile) {
      // File already exists - check if it's the same version
      if (existingFile.version === version) {
        // Exact same file and version - return existing record
        console.log(`♻️  File already exists: ${appName} v${version} (${platform})`);
        
        // Clean up temporary file
        if (fs.existsSync(req.file.path)) {
          fs.unlinkSync(req.file.path);
        }
        
        return res.json({
          success: true,
          message: 'File already exists - using existing version',
          data: {
            id: existingFile._id,
            name: existingFile.name,
            version: existingFile.version,
            platform: existingFile.platform,
            fileSize: existingFile.fileSize,
            checksum: existingFile.checksum,
            uploadDate: existingFile.createdAt,
            gridfsFileId: existingFile.fileId,
            isDuplicate: true
          }
        });
      } else {
        // Same file but different version - this shouldn't happen, but handle it
        console.log(`⚠️  Same file content but different version: existing v${existingFile.version} vs new v${version}`);
        
        // Clean up temporary file
        if (fs.existsSync(req.file.path)) {
          fs.unlinkSync(req.file.path);
        }
        
        return res.status(400).json({
          success: false,
          message: `This file already exists as version ${existingFile.version}. Cannot upload same file with different version ${version}.`
        });
      }
    }
    
    // Check if this app+version combination already exists with different file
    const existingVersion = await ApkData.findOne({
      name: appName,
      version: version,
      platform: platform
    });
    
    if (existingVersion) {
      // Version exists but different file - update it
      console.log(`🔄 Updating existing version: ${appName} v${version} (${platform})`);
      
      // Delete old file from GridFS
      try {
        await fileStorage.deleteApkFile(existingVersion.fileId);
        console.log(`🗑️  Deleted old file: ${existingVersion.fileId}`);
      } catch (deleteError) {
        console.error('⚠️  Failed to delete old file:', deleteError);
      }
      
      // Store new file in GridFS
      console.log('📤 Storing updated file in GridFS...');
      const fileResult = await fileStorage.storeApkFile(req.file.path, {
        originalName: req.file.originalname,
        appName: appName,
        version: version,
        platform: platform
      });
      
      // Update existing record
      existingVersion.fileId = fileResult.fileId;
      existingVersion.fileSize = fileResult.size;
      existingVersion.checksum = fileResult.checksum;
      existingVersion.uploadDate = new Date();
      
      await existingVersion.save();
      
      // Clean up temporary file
      if (fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
      }
      
      console.log(`📱 APK updated: ${appName} v${version} (${platform})`);
      
      return res.json({
        success: true,
        message: 'APK version updated successfully',
        data: {
          id: existingVersion._id,
          name: existingVersion.name,
          version: existingVersion.version,
          platform: existingVersion.platform,
          fileSize: existingVersion.fileSize,
          checksum: existingVersion.checksum,
          uploadDate: existingVersion.uploadDate,
          gridfsFileId: fileResult.fileId,
          isUpdate: true
        }
      });
    }

    // New file and version - store it
    console.log('📤 Storing new file in GridFS...');
    const fileResult = await fileStorage.storeApkFile(req.file.path, {
      originalName: req.file.originalname,
      appName: appName,
      version: version,
      platform: platform
    });

    // Create new APK record in database
    const apkRecord = new ApkData({
      name: appName,
      version: version,
      platform: platform,
      fileId: fileResult.fileId,
      fileSize: fileResult.size,
      checksum: fileResult.checksum,
      totalDownloads: 0,
      isActive: true
    });

    await apkRecord.save();

    // Clean up temporary file
    if (fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }
    
    console.log(`📱 APK uploaded: ${appName} v${version} (${platform})`);
    
    // Generate fast download URLs
    const baseUrl = process.env.BASE_URL || `http://${req.get('host')}`;
    const fastDownloadUrl = `${baseUrl}/download/${apkRecord._id}`;
    const directDownloadUrl = `${baseUrl}/api/updates/download/${platform}`;
    
    res.json({
      success: true,
      message: 'APK uploaded successfully',
      data: {
        id: apkRecord._id,
        name: apkRecord.name,
        version: apkRecord.version,
        platform: apkRecord.platform,
        fileSize: apkRecord.fileSize,
        checksum: apkRecord.checksum,
        uploadDate: apkRecord.createdAt,
        gridfsFileId: fileResult.fileId,
        downloadUrls: {
          fast: fastDownloadUrl,
          direct: directDownloadUrl,
          latest: `${baseUrl}/download/latest/${platform}`
        }
      }
    });
  } catch (error) {
    console.error('❌ Upload error:', error);
    console.error('Error stack:', error.stack);
    
    // Clean up temporary file on error
    try {
      if (req.file && fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
        console.log('🧹 Cleaned up temporary file:', req.file.path);
      }
    } catch (cleanupError) {
      console.error('❌ Failed to cleanup temporary file:', cleanupError);
    }
    
    res.status(500).json({
      success: false,
      message: 'Upload failed: ' + error.message,
      details: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});

// Fast download route by APK ID
app.get('/download/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Find APK by ID
    const apkData = await ApkData.findById(id);
    
    if (!apkData || !apkData.isActive) {
      return res.status(404).json({
        success: false,
        message: 'APK not found or inactive'
      });
    }
    
    // Track download
    await trackUpdateEvent('download_start', null, apkData.version, apkData.platform, req.get('User-Agent'));
    
    // Increment download count
    apkData.totalDownloads += 1;
    await apkData.save();
    
    console.log(`⬇️  Fast download: ${apkData.name} v${apkData.version} (${apkData.platform})`);
    
    // Set headers for download
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Disposition', `attachment; filename="${apkData.name}-v${apkData.version}.apk"`);
    res.setHeader('Content-Length', apkData.fileSize);
    res.setHeader('Cache-Control', 'public, max-age=3600'); // Cache for 1 hour
    
    // Stream file from GridFS
    const downloadStream = fileStorage.getApkFileStream(apkData.fileId);
    
    downloadStream.on('error', (error) => {
      console.error('❌ Download stream error:', error);
      if (!res.headersSent) {
        res.status(500).json({
          success: false,
          message: 'Download failed: ' + error.message
        });
      }
    });
    
    downloadStream.pipe(res);
    
  } catch (error) {
    console.error('❌ Fast download error:', error);
    res.status(500).json({
      success: false,
      message: 'Download failed: ' + error.message
    });
  }
});

// Download latest version by platform
app.get('/download/latest/:platform', async (req, res) => {
  try {
    const { platform } = req.params;
    
    // Find latest APK for platform
    const latestApk = await ApkData.findOne({ 
      platform: platform,
      isActive: true 
    }).sort({ uploadDate: -1 });
    
    if (!latestApk) {
      return res.status(404).json({
        success: false,
        message: `No APK found for platform: ${platform}`
      });
    }
    
    // Redirect to fast download
    res.redirect(`/download/${latestApk._id}`);
    
  } catch (error) {
    console.error('❌ Latest download error:', error);
    res.status(500).json({
      success: false,
      message: 'Download failed: ' + error.message
    });
  }
});

// Download route with token
app.get('/d/:token', async (req, res) => {
  try {
    const { token } = req.params;
    const linkData = await DownloadLink.findOne({ token: token });
    
    if (!linkData) {
      return res.status(404).send(`
        <html>
          <body style="font-family: Arial; text-align: center; padding: 50px;">
            <h2>❌ Invalid Download Link</h2>
            <p>This download link is not valid or has expired.</p>
          </body>
        </html>
      `);
    }
    
    if (!linkData.isActive) {
      return res.status(403).send(`
        <html>
          <body style="font-family: Arial; text-align: center; padding: 50px;">
            <h2>🚫 Download Disabled</h2>
            <p>Downloads for this channel have been temporarily disabled.</p>
          </body>
        </html>
      `);
    }
    
    // Get latest APK
    const latestApk = await ApkData.findOne({ isActive: true }).sort({ uploadDate: -1 });
    
    if (!latestApk || !latestApk.fileId) {
      return res.status(404).send(`
        <html>
          <body style="font-family: Arial; text-align: center; padding: 50px;">
            <h2>📱 No APK Available</h2>
            <p>No APK file is currently available for download.</p>
          </body>
        </html>
      `);
    }
    
    // Increment download counts
    await ApkData.findByIdAndUpdate(latestApk._id, { $inc: { totalDownloads: 1 } });
    await DownloadLink.findByIdAndUpdate(linkData._id, { 
      $inc: { downloadCount: 1 },
      $set: { lastAccessedAt: new Date() }
    });
    
    // Set headers for APK download
    const fileName = `${latestApk.name}_v${latestApk.version}.apk`;
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Length', latestApk.fileSize || 0);
    
    try {
      // Stream the file from GridFS
      const fileStream = fileStorage.getApkFileStream(latestApk.fileId);
      
      fileStream.on('error', (error) => {
        console.error('Download stream error:', error);
        if (!res.headersSent) {
          res.status(500).send('Download failed');
        }
      });
      
      fileStream.on('end', () => {
        console.log(`📱 Download: ${linkData.channelName} (${linkData.channelId}) - ${latestApk.name} v${latestApk.version}`);
      });
      
      fileStream.pipe(res);
    } catch (streamError) {
      console.error('GridFS stream error:', streamError);
      res.status(500).send('File stream failed');
    }
    
  } catch (error) {
    console.error('Download error:', error);
    res.status(500).send('Download failed: ' + error.message);
  }
});

// GET - Get file storage statistics (Admin endpoint)
app.get('/api/storage/stats', async (req, res) => {
  try {
    const stats = await fileStorage.getStorageStats();
    const apkCount = await ApkData.countDocuments();
    
    res.json({
      success: true,
      storage: {
        totalFiles: stats.totalFiles,
        totalSize: stats.totalSize,
        totalSizeMB: (stats.totalSize / (1024 * 1024)).toFixed(2),
        averageSize: stats.averageSize,
        averageSizeMB: (stats.averageSize / (1024 * 1024)).toFixed(2),
        oldestFile: stats.oldestFile,
        newestFile: stats.newestFile
      },
      database: {
        apkRecords: apkCount
      }
    });
  } catch (error) {
    console.error('Storage stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get storage statistics: ' + error.message
    });
  }
});

// GET - List all APK files (Admin endpoint)
app.get('/api/storage/files', async (req, res) => {
  try {
    const { limit = 20 } = req.query;
    const files = await fileStorage.listApkFiles(parseInt(limit));
    
    res.json({
      success: true,
      files: files.map(file => ({
        id: file._id,
        filename: file.filename,
        length: file.length,
        uploadDate: file.uploadDate,
        metadata: file.metadata
      }))
    });
  } catch (error) {
    console.error('List files error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to list files: ' + error.message
    });
  }
});

// DELETE - Clean up old files (Admin endpoint)
app.delete('/api/storage/cleanup', async (req, res) => {
  try {
    const { daysOld = 30 } = req.query;
    const deletedCount = await fileStorage.cleanupOldFiles(parseInt(daysOld));
    
    res.json({
      success: true,
      message: `Cleaned up ${deletedCount} old files`,
      deletedCount
    });
  } catch (error) {
    console.error('Cleanup error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to cleanup files: ' + error.message
    });
  }
});

// GET - Get file metadata (Admin endpoint)
app.get('/api/storage/file/:fileId/metadata', async (req, res) => {
  try {
    const { fileId } = req.params;
    const metadata = await fileStorage.getFileMetadata(fileId);
    
    res.json({
      success: true,
      metadata
    });
  } catch (error) {
    console.error('File metadata error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get file metadata: ' + error.message
    });
  }
});

// DELETE - Delete specific file (Admin endpoint)
app.delete('/api/storage/file/:fileId', async (req, res) => {
  try {
    const { fileId } = req.params;
    
    // First check if file exists in database
    const apkRecord = await ApkData.findOne({ fileId: fileId });
    if (apkRecord) {
      await ApkData.findByIdAndDelete(apkRecord._id);
    }
    
    // Delete from GridFS
    await fileStorage.deleteApkFile(fileId);
    
    res.json({
      success: true,
      message: 'File deleted successfully'
    });
  } catch (error) {
    console.error('Delete file error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete file: ' + error.message
    });
  }
});

// Telegram webhook endpoint (for future integration)
app.post('/webhook/telegram/:token', (req, res) => {
  try {
    const { token } = req.params;
    const update = req.body;
    
    // Here you can handle Telegram webhook updates
    // For example, automatically respond to users with download links
    
    console.log(`Telegram webhook for token ${token}:`, update);
    
    res.json({ success: true });
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Error:', error);
  res.status(500).json({
    success: false,
    message: 'Internal server error'
  });
});

// 404 handler - distinguish between API and page requests
app.use((req, res) => {
  // If it's an API request, return JSON
  if (req.path.startsWith('/api/')) {
    res.status(404).json({
      success: false,
      message: `API endpoint not found: ${req.method} ${req.path}`,
      error: 'NOT_FOUND'
    });
  } else {
    // For non-API requests, redirect to login
    res.redirect('/login');
  }
});

// Start server with database initialization
async function startServer() {
  try {
    // Initialize database connection
    await initializeDatabase();
    
    // Start the HTTP server
    const server = app.listen(PORT, HOST, () => {
  const address = server.address();
  const host = address.address === '::' ? 'localhost' : address.address;
  
  console.log(`🚀 Telegram APK Download Server running on http://${host}:${address.port}`);
  console.log(`📱 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🌐 Host: ${HOST} | Port: ${PORT}`);
  
  if (IS_PRODUCTION) {
    console.log(`🔒 Production mode enabled with enhanced security`);
    console.log(`🛡️  Rate limiting: ${UPDATE_CONFIG.rateLimitMax} requests per ${UPDATE_CONFIG.rateLimitWindow/1000/60} minutes`);
    console.log(`📋 Device registration required: ${UPDATE_CONFIG.requireDeviceRegistration}`);
  }
  
  console.log(`\n📋 Available API Endpoints:`);
  console.log(`\n🔐 Authentication APIs:`);
  console.log(`   POST /api/auth/login         - Admin login`);
  console.log(`   POST /api/auth/logout        - Admin logout`);
  console.log(`   GET  /api/auth/me            - Verify token & get admin info`);
  console.log(`   POST /api/auth/change-password - Change admin password`);
  console.log(`\n🔄 Update Management APIs:`);
  console.log(`   POST /api/check-version      - Check for app updates`);
  console.log(`   GET  /api/updates/:platform  - Get update metadata`);
  console.log(`   GET  /api/updates/download/:platform - Download update`);
  console.log(`   POST /api/updates/register   - Register device for updates`);
  console.log(`   POST /api/analytics/update   - Track update events`);
  console.log(`   GET  /api/analytics/updates  - Get update analytics`);
  console.log(`   POST /api/notifications/update - Send update notifications`);
  console.log(`   GET  /api/devices            - Get registered devices`);
  console.log(`\n📱 App Management APIs:`);
  console.log(`   GET  /health                 - Health check endpoint`);
  console.log(`   GET  /api/stats              - Get download statistics`);
  console.log(`   GET  /api/apps               - Get all apps`);
  console.log(`   GET  /api/versions/:appName  - Get all versions of an app`);
  console.log(`   POST /upload                 - Upload new APK (🔐 Admin)`);
  
  console.log(`\n⚡ Fast Download APIs:`);
  console.log(`   GET  /download/:id           - Fast download by APK ID`);
  console.log(`   GET  /download/latest/:platform - Download latest version`);
  console.log(`   GET  /d/:token              - Download APK with token`);
  
  console.log(`\n📱 Channel Management APIs (🔐 Admin):`);
  console.log(`   GET  /api/channels           - Get all channels`);
  console.log(`   POST /api/channels           - Add new channel`);
  console.log(`   PUT  /api/channels/:token/toggle - Toggle channel status`);
  console.log(`   DELETE /api/channels/:token  - Delete channel`);
  console.log(`\n📁 File Storage APIs (GridFS):`);
  console.log(`   GET  /api/storage/stats      - Get storage statistics`);
  console.log(`   GET  /api/storage/files      - List all APK files`);
  console.log(`   GET  /api/storage/file/:id/metadata - Get file metadata`);
  console.log(`   DELETE /api/storage/file/:id - Delete specific file`);
  console.log(`   DELETE /api/storage/cleanup  - Clean up old files`);
  console.log(`\n🔗 Integration APIs:`);
  console.log(`   POST /webhook/telegram/:token - Telegram webhook (future)`);
  
  console.log(`\n🔐 Admin Authentication:`);
  console.log(`   Username: ${AUTH_CONFIG.adminUsername}`);
  console.log(`   Password: ${AUTH_CONFIG.adminPassword.startsWith('$2b$') ? '[HASHED]' : '[PLAIN TEXT - Change in production!]'}`);
  console.log(`   JWT Expires: ${AUTH_CONFIG.jwtExpiresIn}`);
  console.log(`   Max Login Attempts: ${AUTH_CONFIG.maxLoginAttempts}`);
  
  if (!IS_PRODUCTION) {
    console.log(`\n🔧 Development mode - Access at: http://localhost:${PORT}`);
    console.log(`\n🔑 Default Admin Credentials:`);
    console.log(`   Username: ${AUTH_CONFIG.adminUsername}`);
    console.log(`   Password: ${AUTH_CONFIG.adminPassword}`);
    console.log(`\n🌐 Admin Pages:`);
    console.log(`   Login: http://localhost:${PORT}/login`);
    console.log(`   Dashboard: http://localhost:${PORT}/dashboard`);
    console.log(`   Upload Manager: http://localhost:${PORT}/upload`);
    console.log(`   Channel Manager: http://localhost:${PORT}/channels`);
  }
    });
    
    // Handle server shutdown
    process.on('SIGTERM', async () => {
      console.log('🛑 SIGTERM received, shutting down gracefully...');
      await dbConnection.disconnect();
      server.close(() => {
        process.exit(0);
      });
    });

    process.on('SIGINT', async () => {
      console.log('🛑 SIGINT received, shutting down gracefully...');
      await dbConnection.disconnect();
      server.close(() => {
        process.exit(0);
      });
    });

  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();

module.exports = app;